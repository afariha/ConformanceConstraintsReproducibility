#include "unittest.hpp"

int main(int argc, char** argv) {
    return unittest::make_default_environment(argc, argv);
}
